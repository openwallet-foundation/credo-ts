import type { Anoncreds } from '@hyperledger/anoncreds-shared'

export const AnonCredsRsSymbol = Symbol('AnonCredsRs')
export type { Anoncreds }
