export interface AnonCredsCreateMasterSecretOptions {
  masterSecretId?: string
  setAsDefault?: boolean
}
